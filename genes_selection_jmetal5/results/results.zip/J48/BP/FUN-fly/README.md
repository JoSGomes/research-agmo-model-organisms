# This Project is destinated to agmo-model-organism using the JMETAL 5
* Important points
  * Using JDK LTS (20 at the moment - 03/2023)
  * Maven 3.9.3