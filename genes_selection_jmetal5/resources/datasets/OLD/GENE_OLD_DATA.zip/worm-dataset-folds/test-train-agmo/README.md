# Sobre este diretório

Esses são os folds para relizar o test-train no agmo, no caso aqui apresentado apenas o FOLD TRAIN-TEST-0 está sendo utilizado no gridsearch, por motivos de otimização.

