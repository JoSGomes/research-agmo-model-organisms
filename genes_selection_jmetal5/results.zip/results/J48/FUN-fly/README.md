# agmo-model-organisms
This work is about the application of genetic algorithms multiobjective in the feature selection of model organisms datasets
